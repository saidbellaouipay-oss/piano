PIANO TILES LITE - SOURCE CODE PROJECT
Package Name: com.pianotiles.lite
App Name: Piano Tiles Lite

INCLUDED FILES:
1. index.html - Complete single-file game code (HTML5 + Web Audio + Canvas).
2. manifest.json - Web app manifest for PWA & APK builders.
3. capacitor.config.json - Capacitor config to wrap and generate an Android Studio project.

TO RUN LOCALLY:
Just double-click 'index.html' to open and play directly in any browser.

TO BUILD APK:
- Option A: Upload files to https://www.pwabuilder.com and download APK directly.
- Option B: Use Capacitor CLI:
    npx @capacitor/cli create
    npx cap add android
    npx cap build
